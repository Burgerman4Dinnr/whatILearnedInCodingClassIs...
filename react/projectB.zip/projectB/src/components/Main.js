import Meme from '../components/Meme'

const Main =()=> {
    return(
        <main className="main">
            <Meme />
        </main>
    )
}

export default Main